<?
require_once (__DIR__.'/crest.php');

$result = CRest::call(
		'crm.deal.add',
		['TovarName' => 'afaf', 'TovarPrice' => '12321', ]
	);

echo '<pre>';
	print_r($result);
echo '</pre>';